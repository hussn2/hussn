
const express = require('express');
const axios = require('axios');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 8080;

app.get('/api/attendance', async (req, res) => {
  try {
    const tokenResponse = await axios.post('https://api.eu.crosschexcloud.com/', {
      header: {
        nameSpace: 'authorize.token',
        nameAction: 'token',
        version: '1.0',
        requestId: 'auth-req-001',
        timestamp: new Date().toISOString()
      },
      payload: {
        api_key: process.env.CROSSCHEX_API_KEY,
        api_secret: process.env.CROSSCHEX_API_SECRET
      }
    });

    const token = tokenResponse.data.payload.token;

    const attendanceResponse = await axios.post('https://api.eu.crosschexcloud.com/', {
      header: {
        nameSpace: 'attendance.record',
        nameAction: 'getrecord',
        version: '1.0',
        requestId: 'fetch-attendance-001',
        timestamp: new Date().toISOString()
      },
      authorize: {
        type: 'token',
        token: token
      },
      payload: {
        begin_time: '2025-07-01T00:00:00+00:00',
        end_time: '2025-07-02T23:59:59+00:00',
        order: 'asc',
        page: 1,
        per_page: 50
      }
    });

    res.json(attendanceResponse.data.payload.list);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ error: 'Failed to fetch attendance records' });
  }
});

app.listen(PORT, () => console.log(`API running on port ${PORT}`));
